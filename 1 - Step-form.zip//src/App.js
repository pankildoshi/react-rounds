import "./styles.css";
import TabbedForm from "./components/TabbedForm";

export default function App() {
  return (
    <div className="App">
      <TabbedForm />
    </div>
  );
}
